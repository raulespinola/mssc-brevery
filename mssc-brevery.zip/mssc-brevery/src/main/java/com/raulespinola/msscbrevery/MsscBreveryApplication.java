package com.raulespinola.msscbrevery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsscBreveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsscBreveryApplication.class, args);
	}

}
