package com.raulespinola.msscbrevery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsscBreveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
